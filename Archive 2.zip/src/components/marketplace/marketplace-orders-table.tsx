import { useState } from "react"
import { Link } from "@tanstack/react-router"
import { format } from "date-fns"
import { toast } from "sonner"

import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Button } from "@/components/ui/button"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import { EyeIcon, RefreshCwIcon } from "lucide-react"

import { useMarketplaceOrders } from "@/hooks/useMarketplaceOrders"
import { api, ApiError } from "@/lib/api"
import { EDITABLE_MARKETPLACE_ORDER_STATUSES, type MarketplaceOrder } from "@/types/marketplace"

const statusConfig: Record<string, { label: string; className: string }> = {
    pending: { label: "Pending", className: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400" },
    ongoing: { label: "Ongoing", className: "bg-blue-500/10 text-blue-600 dark:text-blue-400" },
    paid: { label: "Paid", className: "bg-blue-500/10 text-blue-600 dark:text-blue-400" },
    confirmed: { label: "Confirmed", className: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400" },
    preparing: { label: "Preparing", className: "bg-orange-500/10 text-orange-600 dark:text-orange-400" },
    on_the_way: { label: "On the Way", className: "bg-purple-500/10 text-purple-600 dark:text-purple-400" },
    completed: { label: "Completed", className: "bg-green-500/10 text-green-600 dark:text-green-400" },
    cancelled: { label: "Cancelled", className: "bg-zinc-500/10 text-zinc-500" },
}

function formatCurrency(amount: number | string | null | undefined) {
    const value = typeof amount === "string" ? parseFloat(amount) : amount
    if (value == null || Number.isNaN(value)) return "—"
    return new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN" }).format(value)
}

const COLUMN_COUNT = 8

interface Props {
    tab?: "pending" | "ongoing" | "completed"
}

export function MarketplaceOrdersTable({ tab }: Props) {
    const { orders, isLoading, error, refetch } = useMarketplaceOrders({ tab })
    const [updatingId, setUpdatingId] = useState<string | null>(null)

    async function handleStatusChange(order: MarketplaceOrder, status: string) {
        setUpdatingId(order.id)
        try {
            await api.updateMarketplaceOrderStatus(order.id, status)
            toast.success(`Order ${order.order_number} updated`)
            refetch()
        } catch (err) {
            const msg = err instanceof ApiError ? err.message : "Failed to update order status"
            toast.error(msg)
        } finally {
            setUpdatingId(null)
        }
    }

    return (
        <div className="rounded-md border">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Order</TableHead>
                        <TableHead>Items</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Agent</TableHead>
                        <TableHead>Placed</TableHead>
                        <TableHead className="text-right">Update</TableHead>
                        <TableHead className="text-right">Details</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {isLoading ? (
                        Array.from({ length: 5 }).map((_, i) => (
                            <TableRow key={i}>
                                <TableCell><Skeleton className="h-4 w-28" /></TableCell>
                                <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                                <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                                <TableCell><Skeleton className="h-5 w-24 rounded-full" /></TableCell>
                                <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                                <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                                <TableCell><Skeleton className="h-8 w-32 ml-auto" /></TableCell>
                                <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                            </TableRow>
                        ))
                    ) : error ? (
                        <TableRow>
                            <TableCell colSpan={COLUMN_COUNT} className="h-24 text-center text-destructive">
                                <div className="flex flex-col items-center gap-2">
                                    {error}
                                    <Button variant="ghost" size="sm" onClick={() => refetch()} className="gap-1.5">
                                        <RefreshCwIcon className="size-3.5" />
                                        Retry
                                    </Button>
                                </div>
                            </TableCell>
                        </TableRow>
                    ) : orders.length === 0 ? (
                        <TableRow>
                            <TableCell colSpan={COLUMN_COUNT} className="h-24 text-center text-muted-foreground">
                                No marketplace orders found.
                            </TableCell>
                        </TableRow>
                    ) : (
                        orders.map((order) => {
                            const status = statusConfig[order.status] ?? { label: order.status, className: "bg-muted text-muted-foreground" }
                            const isFinal = order.status === "completed" || order.status === "cancelled"
                            return (
                                <TableRow key={order.id}>
                                    <TableCell className="font-medium">{order.order_number}</TableCell>
                                    <TableCell className="text-muted-foreground text-sm">
                                        {order.items?.length ?? 0} item{(order.items?.length ?? 0) === 1 ? "" : "s"}
                                    </TableCell>
                                    <TableCell className="text-sm">{formatCurrency(order.total ?? order.pricing?.total)}</TableCell>
                                    <TableCell>
                                        <Badge className={status.className} variant="outline">
                                            {status.label}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-muted-foreground text-sm">
                                        {order.agent?.full_name ?? order.agent?.name ?? (order.agent_status
                                            ? order.agent_status.replace(/_/g, " ")
                                            : "—")}
                                    </TableCell>
                                    <TableCell className="text-muted-foreground whitespace-nowrap text-sm">
                                        {format(new Date(order.created_at), "MMM d, HH:mm")}
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Select
                                            disabled={isFinal || updatingId === order.id}
                                            value={order.status}
                                            onValueChange={(value) => handleStatusChange(order, value)}
                                        >
                                            <SelectTrigger className="ml-auto w-40" size="sm">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value={order.status} disabled>
                                                    {status.label}
                                                </SelectItem>
                                                {EDITABLE_MARKETPLACE_ORDER_STATUSES
                                                    .filter((s) => s !== order.status)
                                                    .map((s) => (
                                                        <SelectItem key={s} value={s}>
                                                            {statusConfig[s]?.label ?? s}
                                                        </SelectItem>
                                                    ))}
                                            </SelectContent>
                                        </Select>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="ml-auto"
                                            asChild
                                        >
                                            <Link
                                                to="/marketplace/orders/$orderId"
                                                params={{ orderId: order.id }}
                                                aria-label={`View order ${order.order_number}`}
                                            >
                                                <EyeIcon className="size-4" />
                                            </Link>
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            )
                        })
                    )}
                </TableBody>
            </Table>
        </div>
    )
}
